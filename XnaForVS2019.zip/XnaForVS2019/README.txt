Run all of the following commands in order:
1. Install DirectX
2. Install XNA Framework 4.0 Redistribution
3. Install XNA Game Studio 4.0 Platform Tools
4. Install XNA Game Studio 4.0 Shared
5. Install XNA Game Studio 4.0.vsix